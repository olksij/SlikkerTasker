package sh.now.alexbesida.planner

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
